# Main API



# Import Modules
Import-Module "$PSScriptRoot\CoreModules\Desktop\Wallpapper.psm1"




function getWallpapperEnabled {
    return getWallpapperEnabled_System
}








Export-ModuleMember -Function getWallpapperEnabled
