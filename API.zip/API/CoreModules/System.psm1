
function updateSystemParameters {
    try {
        rundll32.exe user32.dll, UpdatePerUserSystemParameters 1, true
    } catch {
        Write-Host "[System] UpdateSystemParameter Fail: $_"

        return $false
    }
}



Export-ModuleMember -Function updateSystemParameters
