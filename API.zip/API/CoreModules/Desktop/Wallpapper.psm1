# This was found by my School, DGI uses it too block 
Import-Module "$PSScriptRoot\..\System.psm1"


function getWallpapperEnabled_System {
    $itemExspectedToBe = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop"
    $value = 0


    try {
        updateSystemParameters

        $name = 'NoChangingWallpaper'

        $t = (Get-ItemProperty -Path $itemExspectedToBe -Name $name -ErrorAction Stop).$name

        $value = $t
    } catch {
        $value = 0
    }


    if (([int]$value) -eq 1) {
        return $false
    }

    return $true
}



function setWallpapperEnabled_System {
    param (
        [int]$value
    )


    $itemExspectedToBe = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop"



    $reverse = 0


    if ([int]$value -eq 1) {
        $reverse = 0
    } else {
        $reverse = 1
    }



    try {
        # Set the Value
        Set-ItemProperty -Path $itemExspectedToBe -Name 'NoChangingWallpaper' -Value $reverse -Type Dword -ErrorAction Stop


        # Update System Parameters
        updateSystemParameters
    } catch {
        Write-Host "[CoreModules/Desktop/Wallpapper] Error while setting WallPapper Enabled: $_"
    }
}




Export-ModuleMember -Function getWallpapperEnabled_System, setWallpapperEnabled_System
