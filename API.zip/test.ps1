Import-Module ".\API"




Write-Host "$(getWallpapperEnabled)"
